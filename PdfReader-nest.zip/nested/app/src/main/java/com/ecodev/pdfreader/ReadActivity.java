package com.ecodev.pdfreader;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Window;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener;
import com.github.barteksc.pdfviewer.listener.OnPageChangeListener;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.github.barteksc.pdfviewer.util.FitPolicy;

public class ReadActivity extends AppCompatActivity implements OnPageChangeListener, OnLoadCompleteListener {

    private int pageNumber = 0;
    private PDFView pdfView;
    int orientation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide();

        setContentView(R.layout.activity_read);

        pdfView.fromAsset("test.pdf")
                .defaultPage(pageNumber)
                .fitEachPage(true)
                .autoSpacing(true)
                .onPageChange(this)
                .onLoad(this)
                .enableAnnotationRendering(true)
                .scrollHandle(new DefaultScrollHandle(this))
                .spacing(10) // in dp
                .pageFitPolicy(FitPolicy.WIDTH)
                .pageSnap(true)
                .pageFling(true)
                .load();

    }

    @Override
    public void onPageChanged(int page, int pageCount) {
        pageNumber = page;
        System.out.println(String.format("%s / %s", pageNumber + 1, pageCount));
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        System.out.println("onSaveInstanceState" + pageNumber);
        outState.putInt("currentPage", pageNumber);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        System.out.println("onRestoreInstanceState" + savedInstanceState.getInt("currentPage"));
        pageNumber = +savedInstanceState.getInt("currentPage");
        System.out.println("onRestoreInstanceState" + pageNumber);
    }

    @Override
    public void loadComplete(int nbPages) {
//        System.out.println("pageNumber" + pageNumber);

        pdfView.jumpTo(pageNumber, true);
        pdfView.setMinZoom((float) 0.4);

    }
}