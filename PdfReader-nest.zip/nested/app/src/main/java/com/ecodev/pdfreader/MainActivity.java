package com.ecodev.pdfreader;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide();

        setContentView(R.layout.activity_main);

        final Runnable r = new Runnable() {
            public void run() {
                Intent intent = new Intent(getApplicationContext(), ReadActivity.class);
                startActivity(intent);
                finish();
            }
        };

        Handler handler = new Handler();

        handler.postDelayed(r, 3000);
    }
}